from setuptools import setup

setup(
    name='Eeron',
    version='1.0.0',
    packages=[''],
    url='https://github.com/Cyrp48/Eeron/tree/maste',
    license='Copyright [2024] [cypr]',
    author='cypr',
    author_email='cyprcyrp@gmail.com',
    description='New organaizer module'
)
